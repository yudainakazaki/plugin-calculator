package Code;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Stack;

public class Main implements Plugin {
    //singleton
    private static Main trigPlugin = new Main();
    private Main(){}
    public static Main getInstance(){
        return trigPlugin;
    }

    private ArrayList<String> operators = new ArrayList<>(Arrays.asList("sin (", "cos (", "tan ("));

    public BigDecimal exec(String operator, Stack<BigDecimal> operands){
//        TRUEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
        BigDecimal val = operands.pop();
        System.out.println("operand????: "+val);
        switch (operator){
            case "sin":
                System.out.println(" fjaka" + BigDecimal.valueOf(Math.sin(val.doubleValue())));
                return BigDecimal.valueOf(Math.sin(val.doubleValue()));
            case "cos":
                return BigDecimal.valueOf(Math.cos(val.doubleValue()));
            case "tan":
                return BigDecimal.valueOf(Math.tan(val.doubleValue()));
            default:
                return null;
        }
    }
    public ArrayList<String> getOperators(){ return operators; }
    public int numOperands(){ return 1; }
}
